
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Connect to MySQL
$servername = "localhost";
$username = "n";
$password = "lovesoccer";
$dbname = "luna";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if image file was uploaded
if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
  // Get file information
  $file_name = $_FILES["image"]["name"];
  $file_size = $_FILES["image"]["size"];
  $file_tmp = $_FILES["image"]["tmp_name"];
  $file_type = $_FILES["image"]["type"];

  // Calculate file extension
  $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

  // Valid file extensions
  $valid_extensions = array("jpg", "jpeg", "png", "gif");

  // Check if file has a valid extension
  if (in_array($file_ext, $valid_extensions)) {
    // Generate a unique filename
    $new_filename = uniqid() . "." . $file_ext;

    // Move uploaded file to a directory on the server
   $upload_dir = $_SERVER['DOCUMENT_ROOT'] . "/luna_pro/luna_pro/images/";
    move_uploaded_file($file_tmp, $upload_dir . $new_filename);

    // Insert file path into MySQL database table
    $sql = "INSERT INTO img (imagex) VALUES ('$new_filename')";
    if ($conn->query($sql) === TRUE) {
      echo "Image uploaded successfully";
    } else {
      echo "Error uploading image: " . $conn->error;
    }
  } else {
    echo "Invalid file extension";
  }
}

// Close MySQL connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="POST" enctype="multipart/form-data">
        <label for="enter file"></label>
        <input type="file" name="image">
        <input type="submit" value="add">
    </form>
    <img src="./images/<?php echo $filename;?>" alt="">
</body>
</html>

<?php

// Connect to MySQL
$servername = "localhost";
$username = "n";
$password = "lovesoccer";
$dbname = "luna";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// Retrieve image file path from MySQL database
$sql = "SELECT imagex FROM img ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Output image file using <img> element
  $row = $result->fetch_assoc();
  $filename = $row["imagex"];
  echo "<img src=./images/$filename'>";
} else {
    echo "No images found";
  }
  
  // Close MySQL connection
  $conn->close();
  ?>