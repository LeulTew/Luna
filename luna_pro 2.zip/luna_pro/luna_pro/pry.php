<?php
// Include the database connection file
include('connection.php');

// Define variables to store form data
$title = $genre = $description = $released_date = $duration = $director = $main_actors = $rating = $no_views = $images = $poster = '';

// Define error variables to store error messages
$errors = array();

// Validate and sanitize form inputs
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate title
    if (empty($_POST['title'])) {
        $errors['title'] = "Title is required <br>";
    } else {
        $title = sanitizeInput($_POST['title']);
        if (!preg_match('/^[a-zA-Z\s]+$/', $title)) {
            $errors['title'] = "Title must be only letters and spaces <br>";
        }
    }

    // Validate genre
    if (empty($_POST['genre'])) {
        $errors['genre'] = "Genre is required <br>";
    } else {
        $genre = sanitizeInput($_POST['genre']);
        if (!preg_match('/^[a-zA-Z\s]+$/', $genre)) {
            $errors['genre'] = "Genre must be only letters and spaces <br>";
        }
    }

    // Validate description
    if (empty($_POST['description'])) {
        $errors['description'] = "Description is required <br>";
    } else {
        $description = sanitizeInput($_POST['description']);
    }

    // Validate released_date
    if (empty($_POST['released_date'])) {
        $errors['released_date'] = "Released date is required <br>";
    } else {
        $released_date = sanitizeInput($_POST['released_date']);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $released_date)) {
            $errors['released_date'] = "Released date must be in the format yyyy-mm-dd <br>";
        }
    }

    // Validate duration
    if (empty($_POST['duration'])) {
        $errors['duration'] = "Duration is required <br>";
    } else {
        $duration = sanitizeInput($_POST['duration']);
        if (!is_numeric($duration)) {
            $errors['duration'] = "Duration must be a number <br>";
        }
    }

    // Validate director
    if (empty($_POST['director'])) {
        $errors['director'] = "Director is required <br>";
    } else {
        $director = sanitizeInput($_POST['director']);
        if (!preg_match('/^[a-zA-Z\s]+$/', $director)) {
            $errors['director'] = "Director must be only letters and spaces <br>";
        }
    }

    // Validate main_actors
    if (empty($_POST['main_actors'])) {
        $errors['main_actors'] = "Main actors are required <br>";
    } else {
        $main_actors = sanitizeInput($_POST['main_actors']);
        if (!preg_match('/^[a-zA-Z\s]+$/', $main_actors)) {
            $errors['main_actors'] = "Main actors must be only letters and spaces <br>";
        }
    }

    // Validate rating
    if (empty($_POST['rating'])) {
        $errors['rating'] = "Rating is required <br>";
    } else {
        $rating = sanitizeInput($_POST['rating']);
        if (!is_numeric($rating)) {
            $errors['rating'] = "Rating must be a number <br>";
        } else if ($rating < 0 || $rating > 10) {
            $errors['rating'] = "Rating must be between 0 and 10 <br>";
        }
    }

    // Validate no_views
    if (empty($_POST['no_views'])) {
        $errors['no_views'] = "Number of views is required <br>";
    } else {
        $no_views = sanitizeInput($_POST['no_views']);
        if (!is_numeric($no_views) || $no_views<0) {
            $errors['no_views'] = "Number of views must be a number postive <br>";
        }
    }

    // Validate images
    if (empty($_FILES['images']['name'])) {
        $errors['images'] = "Images are required <br>";
    } else {
        $images = sanitizeInput($_FILES['images']['name']);
    }

    // Validate poster
    if (empty($_FILES['poster']['name'])) {
        $errors['poster'] = "Poster is required <br>";
    } else {
        $poster = sanitizeInput($_FILES['poster']['name']);
    }

    // If there are no errors, insert data into the movies table
    if (count($errors) == 0) {
        // Upload images
        $targetDir =  $_SERVER['DOCUMENT_ROOT'] . "/luna_pro/luna_pro/images/";
        $targetImage = $targetDir . basename($_FILES['images']['name']);
        $targetPoster = $targetDir . basename($_FILES['poster']['name']);

        move_uploaded_file($_FILES['images']['tmp_name'], $targetImage);
        move_uploaded_file($_FILES['poster']['tmp_name'], $targetPoster);

        // Insert data into the movies table
        $sql = "INSERT INTO movies (title, genre, descriptions, released_date, duration, director, main_actors, rating, no_views, images) VALUES ('$title', '$genre', '$description', '$released_date', $duration, '$director', '$main_actors', $rating, $no_views, '$images')";

        $result = mysqli_query($con, $sql);
        if ($result) {
            $answer=" Success!";
             /* header('Location:index.php'); */
          /*    exit(); */ 
        } else {
            // Error occurred
            echo mysqli_error($con);
        }
    }
}


// Function to sanitize form inputs
function sanitizeInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Close the database connection
$con->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Movie</title>
    <style>
        .error {
            color: red;
        }
    </style>
    <script>
        function validateForm() {
            var title = document.forms["movieForm"]["title"].value;
            var genre = document.forms["movieForm"]["genre"].value;
            var releasedDate = document.forms["movieForm"]["released_date"].value;
            var duration = document.forms["movieForm"]["duration"].value;
            var rating = document.forms["movieForm"]["rating"].value;
            var noViews = document.forms["movieForm"]["no_views"].value;
            var images = document.forms["movieForm"]["images"].value;
            var poster = document.forms["movieForm"]["poster"].value;

            if (title === "") {
                alert("Title is required");
                return false;
            }
            
            if (genre === "") {
                alert("Genre is required");
                return false;
            }

            if (releasedDate === "") {
                alert("Released Date is required");
                return false;
            }

            if (duration === "") {
                alert("Duration is required");
                return false;
            }

            if (isNaN(duration)) {
                alert("Duration must be a number");
                return false;
            }

            if (rating === "") {
                alert("Rating is required");
                return false;
            }

            if (isNaN(rating)) {
                alert("Rating must be a number");
                return false;
            }

            if (noViews === "") {
                alert("Number of Views is required");
                return false;
            }

            if (isNaN(noViews)) {
                alert("Number of Views must be a number");
                return false;
            }

            if (images === "") {
                alert("Images is required");
                return false;
            }

            if (poster === "") {
                alert("Poster is required");
                return false;
            }
        }
    </script>

    <style>
        body {
            font-family: Arial, sans-serif;
            background:url(./images/oig.jpeg); 
            position: center;
            background-repeat: no-repeat;
           background-size: cover;
            
        }
        .container{
            position: center;
            align-items:center ;
            width:100vw;
            height:180vh;
           background:transparent;
           
            

        }

        form h1 {
            text-align: center;
            font-size:64px;
            transform:translatey(-80px);
            transform:translatex(-20px);
            color:#13c6b2;
            
        } 

        form {
            margin-top:10px;
           /*  background-color: #fff; */
            border-radius: 20px;
            margin-left:1px;
            width: 750px;
            height: 85%;
            padding:30px;
            box-shadow: 0px 0px 10px grey;  background:transparent;
          /*   background:rgba(7, 14, 26, 1); */
            align-items:center ;
            
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color:#13c6b2;
        }

        input[type="text"], input[type="date"], input[type="file"], textarea {
            display: block;
            width: 90%;
            text-align:left;
            padding-left: 70px;
            border: none;
            line-height:30px;
            border-radius: 20px;
            margin-bottom: 20px;
            box-shadow: inset 170px 155px 0px rgba(270, 240, 250, 0.3);;
            background:rgba(7, 14, 26, 0.3);
            color:white;
        }

        input[type="submit"] {
            background-color:#13c6b2;
            color: #fff;
            border: none;
            border-radius: 5px;
            margin-top:10px;
            margin-bottom:10px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 20px;
            width:40%;
            margin-left:30%;
            transition: background-color 0.3s ease-in-out;
            
        }

        input[type="submit"]:hover {
            background-color: #3E8E41;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }
        #e {
            color: red;
            margin-bottom: 10px;
        }
        .center-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 90%;
  backdrop-filter: blur(5px);
  background:transparent;
  
}

/* Form container */
.form-container {
margin-top:120px;

  display:grid;
  grid-template-columns:repeat(2,1fr);
  height: 100%;
  background-color:transparent;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.5);
  background:transparent; 
}
.aside_con{
  margin-top:5px;   
  background-image:url(./images/<?php echo htmlspecialchars($poster);?>);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  height:86%;
  width:70%;
  align-items: center;
  padding: 5px 5px;
 
 
}
    .movie-cardA {
    margin-top:5px;      
    width: 100%;
    height:100%;
    box-shadow: 20px 20px 50px rgba(0, 0, 0, 0.5);
    background: rgba(255,255,255,0.7);
    border-radius: 10px;
    padding: 20px;
    overflow: auto;
  }
  
  .movie-cardA img {
    width: 100%;
    border-radius: 10px;
  }
  
  .movie-cardA h2 {
    font-size: 24px;
    margin-top: 10px;
    margin-bottom: 5px;
  }
  
  .movie-cardA p {
    font-size: 14px;
    margin-bottom: 5px;
  }
  
  .movie-cardA .button-group {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 5px;
    margin-top: 10px;
  }
  
  .movie-cardA .button-group button {
    background-color: transparent;
    border: none;
    color: #555;
    font-size: 16px;
    cursor: pointer;
    position: relative;
    padding-left: 20px;
    padding-right: 20px;
  }
  
  .movie-cardA .button-group button:hover {
    color: black;

  }
  .btn {

    display: inline-block;
    font-size: 16px;
    font-weight: bold;
    color: white;
    background-color: rgb(33, 0, 48);
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    text-decoration: none;
    transition: background-color 0.3s ease;
  }
  
  .btn:hover {
    background-color: #0069d9;
  }
       
    </style>
 <!--    name="movieForm" -->
    
<?php require('normal_header.php')?>
    <div class="container">
    <div class="center-container">
    <div class="form-container">
        
   
        <form name="movieForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
        <h1>Add movie</h1><h3><?php echo $answer;?></h3>
  
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?php echo $title;?>">
        <div id=e><?php echo isset($errors['title']) ? $errors['title'] : ''; ?></div>
    
    
        <label for="genre">Genre:</label>
        <input type="text" id="genre" name="genre" value="<?php echo $genre;?>">
        <div id=e><?php echo isset($errors['genre']) ? $errors['genre'] : ''; ?></div>
   
    
        <label for="description">Description:</label>
        <textarea id="description" name="description"><?php echo $description;?></textarea>
        <div id=e><?php echo isset($errors['description']) ? $errors['description'] : ''; ?></div>
   
  
        <label for="released_date">Released Date: format yyyy-mm-dd</label>
        <input type="text" id="released_date" name="released_date" value="<?php echo $released_date;?> " placeholder="Search...">
        <div id=e><?php echo isset($errors['released_date']) ? $errors['released_date'] : ''; ?></div>
  
    
        <label for="duration">Duration:</label>
        <input type="text" id="duration" name="duration" value="<?php echo $duration;?>">
        <div id=e><?php echo isset($errors['duration']) ? $errors['duration'] : ''; ?></div>
   
        <label for="director">Director:</label>
        <input type="text" id="director" name="director" value="<?php echo $director;?>">
        <div id=e><?php echo isset($errors['director']) ? $errors['director'] : ''; ?></div>
   
        <label for="main_actors">Main Actors:</label>
        <input type="text" id="main_actors" name="main_actors" value="<?php echo $main_actors;?>">
        <div id=e><?php echo isset($errors['main_actors']) ? $errors['main_actors'] : ''; ?></div>
  
        <label for="rating">Rating:</label>
        <input type="text" id="rating" name="rating" value="<?php echo $rating;?>">
        <div id=e><?php echo isset($errors['rating']) ? $errors['rating'] : ''; ?></div>
   
        <label for="no_views">Number of Views:</label>
        <input type="text" id="no_views" name="no_views" value="<?php echo $no_views;?>">
        <div id=e><?php echo isset($errors['no_views']) ? $errors['no_views'] : ''; ?></div>
   
        <label for="images">Images:</label>
        <input type="file" id="images" name="images">
        <div id=e><?php echo isset($errors['images']) ? $errors['images'] : ''; ?></div>
 
        <label for="poster">Poster:</label>
        <input type="file" id="poster" name="poster">
        <div id=e><?php echo isset($errors['poster']) ? $errors['poster'] : ''; ?></div>
 
        <input type="submit" value="Submit">
   
</form>
<div class="aside_con">
 <div class="movie-cardA">
    <img src="images/<?php echo htmlspecialchars($images);?>" alt="Movie Poster">
    <h2><?php echo htmlspecialchars($title);?></h2>
    <p>Genre:<?php echo htmlspecialchars($genre);?></p>
    <p>Duration: <?php echo htmlspecialchars($duration);?><i class="fa-solid fa-clock"></i></p>
    <p>rating:<?php echo htmlspecialchars($rating);?><i class="fa-solid fa-star"></i></p>
    <p>Release Year: <?php echo htmlspecialchars($released_date);?></p>
    <p>views: <?php echo htmlspecialchars($no_views);?><i class="fa-solid fa-eye"></i></p>
    <p>Director: <?php echo htmlspecialchars($director);?> </p>
    <p>Cast: <?php echo htmlspecialchars($main_actors);?></p>
    <p>Description: <?php echo htmlspecialchars($description);?></p>
    <div class="button-group">
   <!--       <button class="button-trailer"><span class="button-circle"><i class="fa-solid fa-star"></i></span><h4>Trailer</h4></button> -->
       <a href="#" class="btn btn-primary"><i class="fa-solid fa-clapperboard"></i> Watch Trailer</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-play"></i> Watch Now</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-add"></i> Add to Library</a>
      <!-- <button class="button-watch"><span class="button-circle"></span>Watch</button>
      <button class="button-library"><span class="button-circle"></span>Add to Library</button> -->
    </div>
 </div>
</div>

</div>
</div>
</div>
    
<?php require('footer.php')?>
