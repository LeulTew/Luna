const menuBtn = document.querySelector(".menu-btn");
const navigation = document.querySelector(".navigation");


menuBtn.addEventListener("click", () => {
  menuBtn.classList.toggle("active");
  navigation.classList.toggle("active");
});
function selectMovie(id) {
    // Set the ID of the selected movie in the form
    document.getElementById('movie-id').value = id;
    // Submit the delete form
    document.getElementById('delete-form').submit();
  }