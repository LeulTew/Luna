<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('../connection.php');

$sign = "";

// Check if a movie ID has been submitted via GET
if (isset($_GET['id'])) {
  $id = mysqli_real_escape_string($con, $_GET['id']);

  // Delete the movie from the database
  $sql = "DELETE FROM movies WHERE id = $id";
  if (mysqli_query($con, $sql)) {
    $sign = "Movie with ID $id has been deleted successfully.";
    header('Location: delete.php');
    exit();
  } else {
    $sign = "Error deleting movie with ID $id: " . mysqli_error($con);
  }
}

// Retrieve the list of movies from the database
if (isset($_POST['q'])) {
  $search_term = mysqli_real_escape_string($con, $_POST['q']);
  $sql = "SELECT * FROM movies 
          WHERE title LIKE '%$search_term%'
          ORDER BY title";       
} else {
  $sql = "SELECT * FROM movies
          ORDER BY title";
}
$result = mysqli_query($con, $sql);
$movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_free_result($result);
mysqli_close($con);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Delete Movie</title>
  <link rel="stylesheet" href="delete.css">

</head>
<body>
  <header>
    <a href="#" class="brand">LUNA Stream</a>
    <div class="s">
      <form action="#" method="POST" class="search-form">
        <input type="text" name="q" placeholder="Search...">
        <button type="submit" class="search-button">Search</button>
      </form>
    </div>
    <div class="menu-btn"></div>
    <div class="navigation">
      <div class="navigation-items">
        <a href="http://localhost/web6/">Home</a>
        <a href="http://localhost/luna_pro/luna_pro/">Explore</a>
        <a href="http://localhost/luna_pro/luna_pro/?q=trending">Library</a>
        <a href="#">Settings</a>
      </div>
    </div>
  </header>
  <section class="stage">
    <h1 class="oneh">Movie list</h1>
    <?php foreach($movies as $movie): ?>
      <div class='movie-card'>
        <img src='../images/<?php echo htmlspecialchars($movie['images']); ?>' alt='<?php echo htmlspecialchars($movie['title']); ?>'>
        <div class='movie-info'>
          <h2><?php echo htmlspecialchars($movie['title']); ?></h2>
          <p>Genre: <?php echo htmlspecialchars($movie['genre']); ?></p>
          <p>Release Date: <?php echo htmlspecialchars($movie['released_date']); ?></p>
          <p>Duration: <?php echo htmlspecialchars($movie['duration']); ?></p>
          <p>Director: <?php echo htmlspecialchars($movie['director']); ?></p>
          <p>Cast: <?php echo htmlspecialchars($movie['main_actors']); ?></p>
          <p>Rating: <?php echo htmlspecialchars($movie['rating']); ?></p>
          <p>Views: <?php echo htmlspecialchars($movie['no_views']); ?></p>
          <p>Description: <?php echo htmlspecialchars($movie['descriptions']); ?></p>
          <form method="GET" action="">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($movie['id']); ?>">
            <button class="dele-btn" type="submit">Delete</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </section>
  <script>
    const menuBtn = document.querySelector(".menu-btn");
    const navigation = document.querySelector(".navigation");
    menuBtn.addEventListener("click", () => {
      menuBtn.classList.toggle("active");
      navigation.classList.toggle("active");
    });  </script>
  <script src="delete.js"></script>
</body>
</html>