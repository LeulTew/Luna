<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('./connection.php');
$search_term="Search...";
$sign="";
$errors = array();
// Update movie in the database if form is submitted
if (isset($_POST['update_movie'])) {

    // Validate title
    if (empty($_POST['title'])) {
      $errors['title'] = "Title is required <br>";
  } else {
      $title = sanitizeInput($_POST['title']);
      if (!preg_match('/^[a-zA-Z\s]+$/', $title)) {
          $errors['title'] = "Title must be only letters and spaces <br>";
      }
  }

  // Validate genre
  if (empty($_POST['genre'])) {
      $errors['genre'] = "Genre is required <br>";
  } else {
      $genre = sanitizeInput($_POST['genre']);
      if (!preg_match('/^([a-zA-Z\s]+)(,\s*[a-zA-Z\s]*)*$/', $genre)) {
          $errors['genre'] = "Genre must be only letters and spaces <br>";
      }
  }

  // Validate description
  if (empty($_POST['description'])) {
      $errors['description'] = "Description is required <br>";
  } else {
      $description = sanitizeInput($_POST['description']);
  }

  // Validate released_date
  if (empty($_POST['released_date'])) {
      $errors['released_date'] = "Released date is required <br>";
  } else {
      $released_date = sanitizeInput($_POST['released_date']);
      if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $released_date)) {
          $errors['released_date'] = "Released date must be in the format yyyy-mm-dd <br>";
      }
  }

  // Validate duration
  if (empty($_POST['duration'])) {
      $errors['duration'] = "Duration is required <br>";
  } else {
      $duration = sanitizeInput($_POST['duration']);
      if (!is_numeric($duration)) {
          $errors['duration'] = "Duration must be a number <br>";
      }
  }

  // Validate director
  if (empty($_POST['director'])) {
      $errors['director'] = "Director is required <br>";
  } else {
      $director = sanitizeInput($_POST['director']);
      if (!preg_match('/^[a-zA-Z\s]+$/', $director)) {
          $errors['director'] = "Director must be only letters and spaces <br>";
      }
  }

  // Validate main_actors
  if (empty($_POST['main_actors'])) {
      $errors['main_actors'] = "Main actors are required <br>";
  } else {
      $main_actors = sanitizeInput($_POST['main_actors']);
      if (!preg_match('/^([a-zA-Z\s]+)(,\s*[a-zA-Z\s]*)*$/', $main_actors)) {
          $errors['main_actors'] = "Main actors must be only letters and spaces <br>";
      }
  }

  // Validate rating
  if (empty($_POST['rating'])) {
      $errors['rating'] = "Rating is required <br>";
  } else {
      $rating = sanitizeInput($_POST['rating']);
      if (!is_numeric($rating)) {
          $errors['rating'] = "Rating must be a number <br>";
      } else if ($rating < 0 || $rating > 10) {
          $errors['rating'] = "Rating must be between 0 and 10 <br>";
      }
  }

  // Validate no_views
  if (empty($_POST['no_views'])) {
      $errors['no_views'] = "Number of views is required <br>";
  } else {
      $no_views = sanitizeInput($_POST['no_views']);
      if (!is_numeric($no_views) || $no_views<0) {
          $errors['no_views'] = "Number of views must be a number postive <br>";
      }
  }

  // Validate images
  if (empty($_FILES['images']['name'])) {
      $errors['images'] = "Images are required <br>";
  } else {
      $images = sanitizeInput($_FILES['images']['name']);
  }
  if (count($errors) == 0) {
     // Upload images
     $targetDir =  $_SERVER['DOCUMENT_ROOT'] . "/luna_pro/luna_pro/images/";
     $targetImage = $targetDir . basename($_FILES['images']['name']);

     move_uploaded_file($_FILES['images']['tmp_name'], $targetImage);
     // Update the movie in the database
  $sql = "UPDATE movies SET 
  title = '$title',
  genre = '$genre',
  descriptions = '$description',
  released_date = '$released_date',
  duration = '$duration',
  director = '$director',
  main_actors = '$main_actors',
  rating = '$rating',
  no_views = '$no_views',
  images = '$images' 
WHERE id = $id";
if (mysqli_query($con, $sql)){

  $sign = "successfully updated.";
  header('Location: update.php');
  exit();

}
else {
  $sign = "Error updateing movie with ID $id: " . mysqli_error($con);
}

  }
  
 
}
// Retrieve the list of movies from the database
if (isset($_POST['q'])) {
  $search_term = mysqli_real_escape_string($con, $_POST['q']);
  $sql = "SELECT * FROM movies 
          WHERE title LIKE '%$search_term%'
          ORDER BY title";       
} else {
  $sql = "SELECT * FROM movies
          ORDER BY title";
}
$result = mysqli_query($con, $sql);
$movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_free_result($result);

// Function to sanitize form inputs
function sanitizeInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UPDATE MOVIES</title>
  <link rel="stylesheet" href="update.css">
  <link rel="stylesheet" href="./fontawesome-free-6.4.0-web/css/all.css">
  
</head>
<body>
  <header>
    <a href="#" class="brand">LUNA Stream</a>
    <div class="s">
      <form action="#" method="POST" class="search-form">
        <input type="text" name="q" placeholder="<?php echo $search_term?>">
        <button type="submit" class="search-button">Search</button>
      </form>
    </div>
    <div class="menu-btn"></div>
    <div class="navigation">
      <div class="navigation-items">
        <a href="http://localhost/web6/">Home</a>
        <a href="http://localhost/luna_pro/luna_pro/">Explore</a>
        <a href="http://localhost/luna_pro/luna_pro/?q=trending">Library</a>
        <a href="#">Settings</a>
      </div>
    </div>
  </header>
  <section class="stage">
   <h1>Movies</h1>
    <div class="show">
    <?php foreach($movies as $movie):?>
                    <div class="movie-card" id="<?php echo htmlspecialchars($movie['id']);?>">
                        <div class="movie-image" >
                        
                        <a href="#" id="movie-link-<?php echo $movie['id']; ?>" data-id="<?php echo $movie['id']; ?>">
                          <img src="./images/<?php echo htmlspecialchars($movie['images']);?>" alt="Movie Poster">
                        </a>
                          <div class="movie-rating">
                            <p><i class="fa-regular fa-star"></i> <?php echo htmlspecialchars($movie['rating']);?></p>
                          </div>
                        </div>
                        <div class="movie-info">
                          <h2 class="movie-title"><?php echo htmlspecialchars($movie['title']);?></h2>
                          <p class="movie-viewers"><i class='fa-solid fa-eye'></i><?php echo htmlspecialchars($movie['no_views']);?> views</p>
                          <p class="movie-duration"><i class='fa-solid fa-clock'></i> <?php echo htmlspecialchars($movie['duration']);?> min</p>
                        </div>
                      </div>
     <?php endforeach;?>

      </div>
    
  </section>
  <form class="mf" name="update_movie" method="post" action="#" enctype="multipart/form-data" id="update-form">
  <input type="hidden" name="id" id="update-id">
   <div class="one">
    <h1>update movie</h1>
    <h3><?php echo $sign?></h3>
    <label for="update-title">Title:</label>
    <input type="text" name="title" id="update-title">
    <div id=e><?php echo isset($errors['title']) ? $errors['title'] : ''; ?></div>

        <label for="update-genre">Genre:</label>
        <input type="text" name="genre" id="update-genre">
        <div id=e><?php echo isset($errors['genre']) ? $errors['genre'] : ''; ?></div>

        <label for="update-description">Description:</label>
        <textarea name="description" id="update-description"></textarea>
        <div id=e><?php echo isset($errors['description']) ? $errors['description'] : ''; ?></div>

        <label for="update-released-date">Released Date:</label>
        <input type="date" name="released_date" id="update-released-date">
        <div id=e><?php echo isset($errors['released_date']) ? $errors['released_date'] : ''; ?></div>
</div>
    
<div class="two">
<label for="update-duration">Duration:</label>
        <input type="number" name="duration" id="update-duration">
        <div id=e><?php echo isset($errors['duration']) ? $errors['duration'] : ''; ?></div>
   
        <label for="update-director">Director:</label>
        <input type="text" name="director" id="update-director">
        <div id=e><?php echo isset($errors['director']) ? $errors['director'] : ''; ?></div>

        <label for="update-main-actors">Main Actors:</label>
        <input type="text" name="main_actors" id="update-main-actors">
        <div id=e><?php echo isset($errors['main_actors']) ? $errors['main_actors'] : ''; ?></div>
   
        <label for="update-rating">Rating:</label>
        <input type="number" name="rating" id="update-rating" step="0.1" min="0" max="10">
        <div id=e><?php echo isset($errors['rating']) ? $errors['rating'] : ''; ?></div>

</div>
<div class="three">
<label for="update-no-views">Number of Views:</label>
        <input type="number" name="no_views" id="update-no-views">
        <div id=e><?php echo isset($errors['no_views']) ? $errors['no_views'] : ''; ?></div>
    
    <label for="images">Images:</label>
    <input type="file" id="update-Images" name="images">
    <div id=e><?php echo isset($errors['images']) ? $errors['images'] : ''; ?></div>
    
    <input type="submit" value="update" name="update_movie">
</div>
</form>
<script>
    // Add click event listener to movie cards
    const movieCards = document.querySelectorAll('.movie-card');
    movieCards.forEach(card => {
      card.addEventListener('click', () => {
        // Get the movie ID from the card's ID attribute
        const movieId = card.getAttribute('id');

        // Send a GET request to retrieve the movie data
        const xhr = new XMLHttpRequest();
        xhr.open('GET', `get_movie.php?id=${movieId}`, true);
        xhr.onload = function() {
          if (xhr.status === 200) {
            // Parse the movie data from the response
            const movieData = JSON.parse(xhr.responseText);

            // Populate the update form with the movie data
            document.getElementById('update-id').value = movieData.id;
            document.getElementById('update-title').value = movieData.title;
            document.getElementById('update-genre').value = movieData.genre;
            document.getElementById('update-description').value = movieData.descriptions;
            document.getElementById('update-released-date').value = movieData.released_date;
            document.getElementById('update-duration').value = movieData.duration;
            document.getElementById('update-director').value = movieData.director;
            document.getElementById('update-main-actors').value = movieData.main_actors;
            document.getElementById('update-rating').value = movieData.rating;
            document.getElementById('update-no-views').value = movieData.no_views;
            document.getElementById('update-Images').value = movieData.images;
            
          }
        };
        xhr.send();
      });
    });
  </script>

  <script>
    const menuBtn = document.querySelector(".menu-btn");
    const navigation = document.querySelector(".navigation");
    menuBtn.addEventListener("click", () => {
      menuBtn.classList.toggle("active");
      navigation.classList.toggle("active");
    });
  </script>
</body>
</html>