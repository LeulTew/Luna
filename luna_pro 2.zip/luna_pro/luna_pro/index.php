<?php
include('connection.php');
//write query for all Movies
if(isset($_POST['q'])) {
  $search_term = mysqli_real_escape_string($con, $_POST['q']);
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE title LIKE '%$search_term%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE title LIKE '%$search_term%'
   ORDER BY id";       
} else if (isset($_GET['q']) && $_GET['q'] === 'new') {;
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          ORDER BY released_date DESC" ;
  $sqls = "SELECT rating, images, title, no_views, duration, id 
          FROM series 
          ORDER BY released_date DESC";
}    else if (isset($_GET['q']) && $_GET['q'] === 'top') {
    
    // write query to search for movies orderd by rating 
    $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          ORDER BY rating DESC";
    $sqls = "SELECT rating, images, title, no_views, duration, id 
     FROM series 
     ORDER BY rating DESC";      
}    
else if (isset($_GET['q']) && $_GET['q'] === 'Popular') {
    
  // write query to search for movies orderd by rating 
  $sql = "SELECT rating, images, title, no_views, duration, id 
        FROM movies 
        ORDER BY no_views DESC";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
   FROM series 
   ORDER BY rating DESC";      
} 
else if (isset($_GET['q']) && $_GET['q'] === 'trending') {
  // write query to search for trending movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE no_views > 100000 AND rating > 7.5
          ORDER BY no_views DESC";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE no_views > 100000 AND rating > 7.5
   ORDER BY no_views DESC";        
}
else if (isset($_GET['q']) && $_GET['q'] === 'Bookmark') {
    
  // write query to search for movies orderd by rating 
  $sql = "SELECT rating, images, title, no_views, duration, id 
        FROM movies 
        ORDER BY rating DESC";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
   FROM series 
   ORDER BY rating DESC";      
}  
else if(isset($_GET['q'])&& $_GET['q'] === 'Action') {
 
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%action%' or '%Action%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%action%' or'%Action%'
   ORDER BY id";       
}   
else if(isset($_GET['q'])&& $_GET['q'] === 'Comedy') {
 
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%Comedy%' or '%comedy%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%Comedy%' or '%comedy%'
   ORDER BY id";       
}   
else if(isset($_GET['q'])&& $_GET['q'] === 'Romance') {
 
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%Romance%' or '%romance%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%Romance%' or '%romance%'
   ORDER BY id";       
}   
else if(isset($_GET['q'])&& $_GET['q'] === 'Science_fiction') {
 
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%Science_fiction%' or '%science_fiction%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%Science_fiction%' or '%science_fiction%'
   ORDER BY id";       
}   
else if(isset($_GET['q'])&& $_GET['q'] === 'Thriller') {
 
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%Thriller%' or '%thriller%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%Thriller%' or '%thriller%'
   ORDER BY id";       
}   
else if(isset($_GET['q'])&& $_GET['q'] === 'Horror') {
 
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%Horror%' or '%horror%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%Horror%' or '%horror%'
   ORDER BY id";       
}  
 
else {
  // write query for all movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          ORDER BY id";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
  FROM series 
  ORDER BY id";        
};



// make query and get result
$result = mysqli_query($con, $sql);
$results = mysqli_query($con, $sqls);

// fetch the result rows as an array 
$movies =mysqli_fetch_all($result, MYSQLI_ASSOC); 
$series=mysqli_fetch_all($results, MYSQLI_ASSOC);

// free result memory
mysqli_free_result($result);
mysqli_free_result($results);

// close database connection
mysqli_close($con);
?>
<!DOCTYPE html>

<?php
require('header.php')
?>
    <div class="container">
        <!-- sidebar start  -->
    <div class="sidebar">
        <div class="top">
            <div class="logo">
                <i class="fa-solid fa-moon"> </i>
             <span> LUNA</span>
            </div>
            <i class="fa-solid fa-bars" id="btn"></i>
        </div>
        <div class="user">
            <img src="./images/me.jpg" alt="user" class="user-img">
            <div>
                <p class="bold">MR.Pool</p>
                <p>admin</p>
            </div>
        </div>
        <ul>
            <li><a href="?q="><i class="fa-solid fa-globe"></i><span class="nav-item">All</span></a>
            <span class="tooltip">All</span></li>
            <li><a href="?q=new"><i class="fa-solid fa-lightbulb"></i><span class="nav-item">New</span></a>
             <span class="tooltip">New</span></li>
            <li><a href="?q=top"><i class="fa-solid fa-star"></i><span class="nav-item">top_rated</span></a>
            <span class="tooltip">Top_rated</span></li>
            <li><a href="?q=Popular"><i class="fa-solid fa-users-line"></i><span class="nav-item">Popular</span></a>
            <span class="tooltip">Popular</span></li>   
            <li><a href="?q=trending"><i class="fa-solid fa-fire"></i><span class="nav-item">Trending</span></a>
            <span class="tooltip">Trending</span></li> 
            <li><a href="?q=trending"><i class="fa-solid fa-book"></i><span class="nav-item">Bookmark</span></a>
            <span class="tooltip">Bookmark</span></li> 
            <h4>Genre</h4>
            <li><a href="?q=Action"><i class="fa-solid fa-gun"></i><span class="nav-item">Action</span></a>
            <span class="tooltip">Action</span></li>
            <li><a href="?q=Romance"><i class="fa-solid fa-heart"></i><span class="nav-item">Romance</span></a>
             <span class="tooltip">Romance</span></li>
            <li><a href="?q=Comedy"><i class="fa-sharp fa-solid fa-face-smile"></i><span class="nav-item">Comedy</span></a>
            <span class="tooltip">Comedy</span></li>
            <li><a href="?q=Science_fiction"><i class="fa-sharp fa-solid fa-robot"></i><span class="nav-item">Science_fiction</span></a>
            <span class="tooltip">Science_fiction</span></li>   
            <li><a href="?q=Thriller"><i class="fa-solid fa-jet-fighter"></i></i><span class="nav-item">Thriller</span></a>
            <span class="tooltip">Thriller</span></li>
            <li><a href="?q=Horror"><i class="fa-solid fa-ghost"></i><span class="nav-item">Horror</span></a>
            <span class="tooltip">Horror</span></li>

        </ul>
    </div>
    <!-- end of side bar  -->

    <div class="main-content">
        <section class="tv">
            
            <div class="movie">
                <h1 class="m_lable">Movies</h1>
                <div class="movie_list">
                <?php foreach($movies as $movie):?>
                    <div class="movie-cardm" id="<?php echo htmlspecialchars($movie['id']);?>">
                        <div class="movie-imagem" >
                        
                        <a href="#" id="movie-link-<?php echo $movie['id']; ?>" data-id="<?php echo $movie['id']; ?>" data-id="<?php echo htmlspecialchars($movie['id']);?>">
                          <img src="./images/<?php echo htmlspecialchars($movie['images']);?>" alt="Movie Poster">
                        </a>
                          <div class="movie-ratingm">
                            <p><i class="fa-regular fa-star" style="color:red;"></i><?php echo htmlspecialchars($movie['rating']);?></p>
                          </div>
                        </div>
                        <div class="movie-infom">
                          <h2 class="movie-titlem"><?php echo htmlspecialchars($movie['title']);?></h2>
                          <p class="movie-viewersm"><i class='fa-solid fa-eye' style="color:red;"></i> <?php echo htmlspecialchars($movie['no_views']);?> views</p>
                          <p class="movie-durationm"><i class='fa-solid fa-clock' style="color:red;"></i> <?php echo htmlspecialchars($movie['duration']);?> min</p>
                          <!-- <p class="movie-release-date">Released on May 27, 2023</p> -->
                        </div>
                      </div>
                      <?php endforeach;?>
                     
                    
                    
                    


                    
                </div>

                </div>
            <div class="series">
                <h1 class="s_lable">Series</h1>
                <div class="series_list">
                <?php foreach($series as $s):?>
                    <div class="movie-cards" id="<?php echo htmlspecialchars($s['id']);?>" data-id="<?php echo htmlspecialchars($movie['id']);?>">
                        <div class="movie-images" >
                          <img src="./images/<?php echo htmlspecialchars($s['images']);?>" alt="Movie Poster">
                          <div class="movie-ratings">
                            <p ><i class="fa-regular fa-star" style="color:red;"></i><?php echo htmlspecialchars($s['rating']);?></p>
                          </div>
                        </div>
                        <div class="movie-infos">
                          <h2 class="movie-titles"><?php echo htmlspecialchars($s['title']);?></h2>
                          <p class="movie-viewerss"><i class='fa-solid fa-eye' style="color:red;"></i> <?php echo htmlspecialchars($s['no_views']);?> views</p>
                          <p class="movie-durations"><i class='fa-solid fa-clock' style="color:red;"></i> <?php echo htmlspecialchars($s['duration']);?> min</p>
                          <!-- <p class="movie-release-date">Released on May 27, 2023</p> -->
                        </div>
                      </div>
                      <?php endforeach;?>
                </div>
            </div>
           
        </section>
        <!-- ================================================================================================== -->
        <aside id="d2">
            
        </aside>
       
    </div>
    
</div>
<script src="new_index.js">const clickables = document.querySelectorAll('.movie-cardm');
const clickables1 = document.querySelectorAll('.movie-cards');
const conk = document.querySelectorAll('aside');

clickables.forEach(clickable => {
  clickable.addEventListener('click', () => {
    conk.classList.toggle('a');
    const id = clickable.getAttribute('data-id');
    side_show(id);
  });
});
clickables1.forEach(clickable1 => {
  clickable1.addEventListener('click', () => {
    conk.classList.toggle('a');
    const id = clickable1.getAttribute('data-id');
    side_show(id);
  });
});

function side_show(id) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', `aside_con.php?id=${id}`);
  xhr.onload = function() {
    if (xhr.status === 200) {
      document.getElementById('d2').innerHTML = xhr.responseText;
    } else {
      console.log('Request failed. Status:', xhr.status);
    }
  };
  xhr.send();
}
function side_show_s(id) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', `aside_con_ser.php?id=${id}`);
  xhr.onload = function() {
    if (xhr.status === 200) {
      document.getElementById('d2').innerHTML = xhr.responseText;
    } else {
      console.log('Request failed. Status:', xhr.status);
    }
  };
  xhr.send();
}</script>
               </body>
                </html>