<?php
require('./connection.php');

$id = mysqli_real_escape_string($con, $_GET['id']);
$sql = "SELECT * FROM movies
        WHERE id = $id";
$result = mysqli_query($con, $sql);
$movieData = mysqli_fetch_assoc($result);
mysqli_free_result($result);

mysqli_close($con);

header('Content-Type: application/json');
echo json_encode($movieData);
?>