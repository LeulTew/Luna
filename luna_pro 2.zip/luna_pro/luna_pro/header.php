<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="header.css">
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="./fontawesome-free-6.4.0-web/css/all.css">
</head>
<body>
<header>
      <a href="#" class="brand">LUNA Stream</a>
      <div class="s">
                <form action="#" method="POST" class="search-form">
                    <input type="text" name="q" placeholder="Search...">
                    <button type="submit" class="search-button">Search</button>
                  </form>
      </div>
      <div class="menu-btn"></div>
      <div class="navigation">
        <div class="navigation-items">
          <a href="http://localhost/web6/">Home</a>
          <a href="http://localhost/luna_pro/">Explore</a>
          <a href="http://localhost/luna_pro/?q=trending">Library</a>
          <a href="#">Settings</a>
        </div>
      </div>
    </header>
    <script>
        const menuBtn = document.querySelector(".menu-btn");
    const navigation = document.querySelector(".navigation");
    

    menuBtn.addEventListener("click", () => {
      menuBtn.classList.toggle("active");
      navigation.classList.toggle("active");
    });
    </script>
