let btn=document.querySelector('#btn');
let  sidebar=document.querySelector('.sidebar');


btn.onclick=function(){
  event.preventDefault();
    sidebar.classList.toggle('active');
};

const clickables = document.querySelectorAll('.movie-cardm');
const clickables1 = document.querySelectorAll('.movie-cards');
const conk = document.querySelectorAll('aside');

clickables.forEach(clickable => {
  clickable.addEventListener('click', () => {
    conk.classList.toggle('a');
    const id = clickable.getAttribute('data-id');
    side_show(id);
  });
});
clickables1.forEach(clickable1 => {
  clickable1.addEventListener('click', () => {
    conk.classList.toggle('a');
    const id = clickable1.getAttribute('data-id');
    side_show(id);
  });
});

function side_show(id) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', `aside_con.php?id=${id}`);
  xhr.onload = function() {
    if (xhr.status === 200) {
      document.getElementById('d2').innerHTML = xhr.responseText;
    } else {
      console.log('Request failed. Status:', xhr.status);
    }
  };
  xhr.send();
}
function side_show_s(id) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', `aside_con_ser.php?id=${id}`);
  xhr.onload = function() {
    if (xhr.status === 200) {
      document.getElementById('d2').innerHTML = xhr.responseText;
    } else {
      console.log('Request failed. Status:', xhr.status);
    }
  };
  xhr.send();
}
// Loop through each link and attach a click event listener
movieLinks.forEach(function(link) {
// Add a double-click event listener to each link
link.addEventListener('dblclick', function(event) {
// Prevent the default behavior of the link
event.preventDefault();

// Get the movie ID from the link's data-id attribute
var movieId = this.getAttribute('data-id');

// Redirect the user to the movie description page with the movie ID as a parameter
window.location.href = '../descc/index.php?id=' + movieId;
});
});





