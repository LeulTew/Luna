<?php require('header.php');?>
    <!-- Form to delete a movie -->
<form id='delete-form' action='delete.php' method='post'>
    <label for="move delete"> Movie to delete</label>
  <input type='text' name='id' id='movie-id'>
  <input type='submit' name='delete' value='delete'>
</form>
    </div>
<?php require('footer.php');?>
<?php
  // Include the database connection file
  include('connection.php');

  // Fetch all movies from the database
  $sql = "SELECT * FROM movies";
  $result = mysqli_query($con, $sql);

  // Display a message if there are no movies in the database
  if (mysqli_num_rows($result) == 0) {
    echo "No movies found.";
  }

  // Loop through all movies and display them in cards
  while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['id'];
    $title = $row['title'];
    $genre = $row['genre'];
    $description = $row['descriptions'];
    $release_date = $row['release_date'];
    $duration = $row['duration'];
    $director = $row['director'];
    $actors = $row['main_actors'];
    $rating = $row['rating'];
    $views = $row['no_views'];
    $images = $row['images'];
    $poster = $row['poster'];


    echo "<div class='container'>";
    echo "<div class='movie-cardq' onclick='selectMovie($id)'>";
    echo "<img src='./images/$images' alt='$title'>";
    echo "<div class='movie-info'>";
    echo "<h2>$title</h2>";
    echo "<p>Genre: $genre</p>";
    echo "<p>Release Date: $release_date</p>";
    echo "<p>Duration: $duration</p>";
    echo "<p>Director: $director</p>";
    echo "<p>Cast: $actors</p>";
    echo "<p>Rating: $rating</p>";
    echo "<p>Views: $views</p>";
    echo "<p>Description: $description</p>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
  }

  // Close the database connection
  mysqli_close($con);
?>



<!-- JavaScript function to select a movie and submit the delete form -->
<script>
  function selectMovie(id) {
    // Set the ID of the selected movie in the form
    document.getElementById('movie-id').value = id;
    // Submit the delete form
    document.getElementById('delete-form').submit();
  }
</script>

<!-- CSS styles for the movie cards -->
<style>
     body {
            font-family: Arial, sans-serif;
            background:url(./images/oig.jpeg); 
            position: center;
            background-size: cover;
     
           
        }
     .container {
   /*  display: flex;
    justify-content: center; */
    display: grid;
    grid-template-columns: 1fr;
    width:80%;
    margin-left:10%;
    margin-top:10%
  }
  .movie-cardq {
    display: grid;
    grid-template-columns: 1fr 1fr;
    margin-bottom: 20px;
    padding: 20px;
    box-shadow: 0px 0px 10px grey;
    background: rgba(255, 255, 255, 0.7);
    border-radius: 10px;
    cursor: pointer;
  }

  .movie-cardq img {
    width: 30%;
    margin-right: 20px;
    border-radius: 10px;
  }

  .movie-cardq .movie-info {
    width: 70%;
  }

  .movie-cardq h2 {
    font-size: 24px;
    margin-bottom: 5px;
  }

  .movie-cardq p {
    font-size: 14px;
    margin-bottom: 5px;
  }

  .btnq {
    display: inline-block;
    font-size: 16px;
    font-weight: bold;
    color: white;
    background-color: rgb(33, 0, 48);
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    text-decoration: none;
    transition: background-color 0.3s ease;
  }

  .btnq:hover {
    background-color: #0069d9;
  }
  .conter{
    justify-self: center;
    margin-top:100px;
    padding:50px 50px;
  }
  #delete-form{
    display:flex;
    flex-direction:column;
    margin-top:10%;
    background-color:transparent;
    width:70%;
    margin-left:15%;

  }
  label {
    text-align:center;

            display: block;
            margin-bottom:10px;
            font-weight: bold;
            color:#13c6b2;
            font-size:50px;
        }
  input[type="text"] {
            display: block;
            width: 85%;
            text-align:left;
            margin-left:70px;
   
            border: none;
            line-height:30px;
            border-radius: 20px;
            margin-bottom: 20px;
            box-shadow: inset 170px 155px 0px rgba(270, 240, 250, 0.3);;
            background:rgba(7, 14, 26, 0.3);
            color:white;
        }
        
        input[type="submit"] {
            background-color:#13c6b2;
            color: #fff;
            border: none;
            border-radius: 5px;
            margin-top:10px;
            margin-bottom:10px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 20px;
            width:40%;
            margin-left:30%;
            transition: background-color 0.3s ease-in-out;
            
        }


</style>
<?php
  // Include the database connection file
  include('connection.php');

  // Get the ID of the movie to be deleted
  $id = $_POST['id'];

  // Delete the movie from the database
  $sql = "DELETE FROM movies WHERE id=$id";
  if (mysqli_query($con, $sql)) {
    // Redirect back to the delete page
    header('Location: delete_page.php');
    exit();
  } else {
    // Display an error message
    echo "Error deleting movie: " . mysqli_error($con);
  }

  // Close the database connection
  mysqli_close($con);
?>