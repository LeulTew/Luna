<?php
include('connection.php');
//write query for all Movies
$genre_term = mysqli_real_escape_string($con, $_POST['gener']);
if(isset($_POST['q'])) {
  $search_term = mysqli_real_escape_string($con, $_POST['q']);
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE title LIKE '%$search_term%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE title LIKE '%$search_term%'
   ORDER BY id";       
} else if (isset($_GET['q']) && $_GET['q'] === 'new') {
  $date = date('Y-m-d', strtotime('-30 days'));
  // write query to search for movies released in the last 30 days
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE release_date >= '$date'
          ORDER BY id";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
          FROM series 
          WHERE release_date >= '$date'
          ORDER BY id";
}    else if (isset($_GET['q']) && $_GET['q'] === 'top') {
    
    // write query to search for movies orderd by rating 
    $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          ORDER BY rating DESC";
    $sqls = "SELECT rating, images, title, no_views, duration, id 
     FROM series 
     ORDER BY rating DESC";      
}    
else if (isset($_GET['q']) && $_GET['q'] === 'Popular') {
    
  // write query to search for movies orderd by rating 
  $sql = "SELECT rating, images, title, no_views, duration, id 
        FROM movies 
        ORDER BY no_views DESC";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
   FROM series 
   ORDER BY rating DESC";      
} 
else if (isset($_GET['q']) && $_GET['q'] === 'trending') {
  // write query to search for trending movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE no_views > 100000 AND rating > 7.5
          ORDER BY no_views DESC";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE no_views > 100000 AND rating > 7.5
   ORDER BY no_views DESC";        
}   
else {
  // write query for all movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          ORDER BY id";
  $sqls = "SELECT rating, images, title, no_views, duration, id 
  FROM series 
  ORDER BY id";        
}
if(isset($_GET['g'])&& $_GET['g'] === 'Action') {
  $g_term = mysqli_real_escape_string($con, $_POST['g']);
  // write query to search for movies
  $sql = "SELECT rating, images, title, no_views, duration, id 
          FROM movies 
          WHERE genre LIKE '%$g_term%'
          ORDER BY id";
  $sqls="SELECT rating, images, title, no_views, duration, id 
   FROM series 
   WHERE genre LIKE '%$search_term%'
   ORDER BY id";       
}

// make query and get result
$result = mysqli_query($con, $sql);
$results = mysqli_query($con, $sqls);

// fetch the result rows as an array 
$movies =mysqli_fetch_all($result, MYSQLI_ASSOC); 
$series=mysqli_fetch_all($results, MYSQLI_ASSOC);

// free result memory
mysqli_free_result($result);
mysqli_free_result($results);

// close database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LUNA</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="./fontawesome-free-6.4.0-web/css/all.css">

</head>
<body>
    <div class="container">
        <!-- sidebar start  -->
    <div class="sidebar">
        <div class="top">
            <div class="logo">
                <i class="fa-solid fa-moon"> </i>
             <span> LUNA</span>
            </div>
            <i class="fa-solid fa-bars" id="btn"></i>
        </div>
        <div class="user">
            <img src="./images/Deadpool_Textless.jpg" alt="user" class="user-img">
            <div>
                <p class="bold">MR.Pool</p>
                <p><?php echo $genre_term;?></p>
            </div>
        </div>
        <ul>
            <li><a href="?q="><i class="fa-solid fa-globe"></i><span class="nav-item">All</span></a>
            <span class="tooltip">All</span></li>
            <li><a href="?q=new"><i class="fa-solid fa-lightbulb"></i><span class="nav-item">New</span></a>
             <span class="tooltip">New</span></li>
            <li><a href="?q=top"><i class="fa-solid fa-star"></i><span class="nav-item">top_rated</span></a>
            <span class="tooltip">Top_rated</span></li>
            <li><a href="?q=Popular"><i class="fa-solid fa-users-line"></i><span class="nav-item">Popular</span></a>
            <span class="tooltip">Popular</span></li>   
            <li><a href="?q=trending"><i class="fa-solid fa-fire"></i><span class="nav-item">Trending</span></a>
            <span class="tooltip">Trending</span></li>
            <h4>Genre</h4>
            <li><a href="?g=Action"><i class="fa-solid fa-gun"></i><span class="nav-item">Action</span></a>
            <span class="tooltip">Action</span></li>
            <li><a href="?g=Romance"><i class="fa-solid fa-heart"></i><span class="nav-item">Romance</span></a>
             <span class="tooltip">Romance</span></li>
            <li><a href="?g=Comedy"><i class="fa-sharp fa-solid fa-face-smile"></i><span class="nav-item">Comedy</span></a>
            <span class="tooltip">Comedy</span></li>
            <li><a href="?g=science"><i class="fa-sharp fa-solid fa-robot"></i><span class="nav-item">Science_fiction</span></a>
            <span class="tooltip">Science fiction</span></li>   
            <li><a href="?g=Thriller"><i class="fa-solid fa-jet-fighter"></i></i><span class="nav-item">Thriller</span></a>
            <span class="tooltip">Thriller</span></li>
            <li><a href="?g=Horror"><i class="fa-solid fa-ghost"></i><span class="nav-item">Horror</span></a>
            <span class="tooltip">Horror</span></li>
           </ul> 
    </div>
    <!-- end of side bar  -->

    <div class="main-content">
        <section>
            <div class="s">
                <form action="#" method="POST" class="search-form">
                    <input type="text" name="q" placeholder="Search...">
                    <button type="submit" class="search-button">Search</button>
                  </form>
            </div>
            <div class="movie">
                <h1 class="m_lable">Movies</h1>
                <div class="movie_list">
                <?php foreach($movies as $movie):?>
                    <div class="movie-card" id="<?php echo htmlspecialchars($movie['id']);?>">
                        <div class="movie-image" >
                          <img src="./images/<?php echo htmlspecialchars($movie['images']);?>" alt="Movie Poster">
                          <div class="movie-rating">
                            <p><i class="fa-regular fa-star"></i><?php echo htmlspecialchars($movie['rating']);?></p>
                          </div>
                        </div>
                        <div class="movie-info">
                          <h2 class="movie-title"><?php echo htmlspecialchars($movie['title']);?></h2>
                          <p class="movie-viewers"><i class='fa-solid fa-eye'></i> <?php echo htmlspecialchars($movie['no_views']);?> views</p>
                          <p class="movie-duration"><i class='fa-solid fa-clock'></i> <?php echo htmlspecialchars($movie['duration']);?> min</p>
                          <!-- <p class="movie-release-date">Released on May 27, 2023</p> -->
                        </div>
                      </div>
                      <?php endforeach;?>
                     
                    
                    
                    


                    
                </div>

                </div>
            <div class="series">
                <h1 class="s_lable">series</h1>
                <div class="series_list">
                <?php foreach($series as $s):?>
                    <div class="movie-card" id="<?php echo htmlspecialchars($s['id']);?>">
                        <div class="movie-image" >
                          <img src="./images/<?php echo htmlspecialchars($s['images']);?>" alt="Movie Poster">
                          <div class="movie-rating">
                            <p><i class="fa-regular fa-star"></i><?php echo htmlspecialchars($s['rating']);?></p>
                          </div>
                        </div>
                        <div class="movie-info">
                          <h2 class="movie-title"><?php echo htmlspecialchars($s['title']);?></h2>
                          <p class="movie-viewers"><i class='fa-solid fa-eye'></i> <?php echo htmlspecialchars($s['no_views']);?> views</p>
                          <p class="movie-duration"><i class='fa-solid fa-clock'></i> <?php echo htmlspecialchars($s['duration']);?> min</p>
                          <!-- <p class="movie-release-date">Released on May 27, 2023</p> -->
                        </div>
                      </div>
                      <?php endforeach;?>
                </div>
            </div>
            <!-- <div class="tv shows">tv shows</div> -->
        </section>
        <aside id="d2">
           <!-- <h1 class="title">Title</h1>
           <div class="movie-card">
            <img src="images/img2.jpg" alt="Movie Poster">
            <div class="movie-info">
              <h2 class="movie-title">Movie Title</h2>
              <p class="movie-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at magna efficitur, faucibus eros vitae, venenatis velit. Fusce vel odio eget mi molestie suscipit ac quis sapien.</p>
              <div class="movie-actions">
                <a href="#" class="watch-trailer">Watch Trailer</a>
                <a href="#" class="buy-tickets">Buy Tickets</a>
              </div>
            </div>
          </div>
 --><!-- <div class="movie-card">
  <div class="movie-image">
    <img src="./images/image4.jpg" alt="Movie Poster">
    <div class="movie-rating">
      <p>8.5</p>
    </div>
  </div>
  <div class="movie-info">
    <h2 class="movie-title">Movie Title</h2>
    <p class="movie-viewers">1,234,567 viewers</p>
    <p class="movie-duration">120 minutes</p>
    <p class="movie-release-date">Released on May 27, 2023</p>
  </div>
</div> -->

  
   <!--  <div class="movie-cardA" >
    <img src="images/img2.jpg" alt="Movie Poster">
    <h2>t</h2>
    <p>Release Year: 2023</p>
    <p>Genre: Action, Adventure, Sci-Fi</p>
    <p>Director: John Doe</p>
    <p>Cast: Jane Doe, Bob Smith, Sarah Lee</p>
    <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    <div class="button-group"> -->
<!--       <button class="button-trailer"><span class="button-circle"><i class="fa-solid fa-star"></i></span><h4>Trailer</h4></button> -->
      <!--  <a href="#" class="btn btn-primary"><i class="fa-solid fa-clapperboard"></i> Watch Trailer</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-play"></i> Watch Now</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-add"></i> Add to Library</a> -->
      <!-- <button class="button-watch"><span class="button-circle"></span>Watch</button>
      <button class="button-library"><span class="button-circle"></span>Add to Library</button> -->
    <!-- </div>
   </div> -->
  </div>
            
        </aside>
    </div>
    
</div>

</body>
<script>
   /*  let btn=document.querySelector('#btn');
    let  sidebar=document.querySelector('.sidebar');


    btn.onclick=function(){
        sidebar.classList.toggle('active');
    }; */

    // Get all clickable elements
/* const clickables = document.querySelectorAll('.movie-card');
const clickables1 = document.querySelectorAll('.series_list .movie-card'); */


// Add click event listener to each clickable elements
/* clickables.forEach(clickable => {
  clickable.addEventListener('click', () => {
    // Get the ID of the clicked element
    const id = clickable.id;
    // Send an AJAX request to fetch data
    const xhr = new XMLHttpRequest();
    xhr.open('get', `aside_con.php?id=${id}`);
    xhr.onload = function() {
      if (xhr.status === 200) {
        // Display the fetched data in the result div
        document.getElementById('d2').innerHTML = xhr.responseText;
      } else {
        console.log('Request failed. Status:', xhr.status);
      }
    };
    xhr.send();
  });
}); */
/* clickables1.forEach(clickable1 => {
  clickable1.addEventListener('click', () => {
    // Get the ID of the clicked element
    const id = clickable1.id;
    // Send an AJAX request to fetch data
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `aside_con_ser.php?id=${id}`);
    xhr.onload = function() {
      if (xhr.status === 200) {
        // Display the fetched data in the result div
        document.getElementById('d2').innerHTML = xhr.responseText;
      } else {
        console.log('Request failed. Status:', xhr.status);
      }
    };
    xhr.send();
  });
}); */
</script>
<script src="index.js"></script>

</html>