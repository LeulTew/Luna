<?php
include('connection.php');

// check if form is submitted
if(isset($_POST['q'])) {
    $search_term = mysqli_real_escape_string($con, $_POST['q']);
    // write query to search for movies
    $sql = "SELECT rating, images, title, no_views, duration, id 
            FROM movies 
            WHERE title LIKE '%$search_term%'
            ORDER BY id";
} else {
    // write query for all movies
    $sql = "SELECT rating, images, title, no_views, duration, id 
            FROM movies 
            ORDER BY id";
}
if (isset($_POST['q'])) {
    $search_term = mysqli_real_escape_string($con, $_POST['q']);
    // write query to search for movies
    $sql = "SELECT rating, images, title, no_views, duration, id 
            FROM movies 
            WHERE title LIKE '%$search_term%'
            ORDER BY id";
  } else if (isset($_GET['q']) && $_GET['q'] === 'new') {
    $today = date('Y-m-d');
    $next_month = date('Y-m-d', strtotime('-30 days'));
    // write query for movies released within 30 days of current date
    $sql = "SELECT rating, images, title, no_views, duration, id 
            FROM movies
            WHERE release_date BETWEEN '$today' AND '$next_month'
            ORDER BY id";
  } else {
    // write query for all movies
    $sql = "SELECT rating, images, title, no_views, duration, id 
            FROM movies 
            ORDER BY id";
  }
// make query and get result
$result = mysqli_query($con, $sql);

// fetch the result rows as an array 
$movies = mysqli_fetch_all($result, MYSQLI_ASSOC); 

// free result memory
mysqli_free_result($result);

// close database connection
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
   
</head>
<body>
    
</body>
</html>