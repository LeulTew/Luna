<?php

include('connection.php');

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the values submitted from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$title = $_POST['title'];
$genre = $_POST['genre'];
$description = $_POST['description'];
$released_date = $_POST['released_date'];
$duration = $_POST['duration'];
$director = $_POST['director'];
$main_actors = $_POST['main_actors'];
$rating = $_POST['rating'];
$no_views = $_POST['no_views'];
$images= $_POST['images'];
}

// SQL query to insert the data into the movies table
$sql = "INSERT INTO movies (title, genre, descriptions, released_date, duration, director, main_actors, rating, no_views, images) VALUES ('$title', '$genre', '$description', '$released_date', '$duration', '$director', '$main_actors', '$rating', '$no_views', '$images')";

if ($con->query($sql) === TRUE) {
    echo "Movie added successfully";
} else {
    echo "Error adding movie: " . $con->error;
}

// Close the database connection
$con->close();

?>

<!DOCTYPE html>
<html>
<head>
	<title>Add Movie</title>
	<style type="text/css">
		label {
			display: block;
			margin-bottom: 10px;
		}
		input[type=text], input[type=date], input[type=number] {
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border: none;
			border-radius: 3px;
			box-shadow: 0px 0px 5px rgba(0,0,0,0.1);
		}
		select {
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border: none;
			border-radius: 3px;
			box-shadow: 0px 0px 5px rgba(0,0,0,0.1);
		}
		button[type=submit] {
			background-color: #4CAF50;
			color: white;
			padding: 10px 20px;
			border: none;
			border-radius: 3px;
			cursor: pointer;
		}
	</style>
</head>
<body>

	<h1>Add Movie</h1>

	<form method="POST" action="addmovie.php.php">
		<label for="title">Title:</label>
		<input type="text" id="title" name="title" required>

		<label for="genre">Genre:</label>
		<select id="genre" name="genre" required>
			<option value="">-- Select Genre --</option>
			<option value="Action">Action</option>
			<option value="Comedy">Comedy</option>
			<option value="Drama">Drama</option>
			<option value="Horror">Horror</option>
			<option value="Science Fiction">Science Fiction</option>
		</select>

		<label for="description">Description:</label>
		<textarea id="description" name="description" rows="5" required></textarea>

		<label for="released_date">Released Date:</label>
		<input type="date" id="released_date" name="released_date" required>

		<label for="duration">Duration (in minutes):</label>
		<input type="number" id="duration" name="duration" required>

		<label for="director">Director:</label>
		<input type="text" id="director" name="director" required>

		<label for="main_actors">Main Actors (comma-separated list):</label>
		<input type="text" id="main_actors" name="main_actors" required>

		<label for="rating">Rating (out of 10):</label>
	    <input type="number" id="rating" name="rating" min="0" max="10" step="0.1" required>

		<label for="no_views">Number of Views:</label>
		<input type="number" id="no_views" name="no_views" required>

		<label for="images">Images:</label>
		<input type="text" id="images" name="images" required>

		<button type="submit">Add Movie</button>
	</form>

</body>
</html>