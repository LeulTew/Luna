<?php
$name="nate ";
$last="solo";
$name.="solo";
echo $name

?>