<?php
include('connection.php');
if(isset($_GET['id'])){
    $id=mysqli_real_escape_string($con,$_GET['id']);
    //make sql
    $sql="SELECT images,title,released_date,genre,director,main_actors,descriptions FROM series WHERE id=$id";
    //get result
    $result=mysqli_query($con,$sql);
    //fetch the result
    $movies=mysqli_fetch_assoc($result);
    //free
    mysqli_free_result($result);
    //close
    mysqli_close($con);
}
 





?>
<!DOCTYPE html>
<html lang="en">
    <style>
        .aside_con{
  background-image:url(./images/<?php echo htmlspecialchars($movies['images']);?>);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  height: 100%;
  width: 100%;
  align-items: center;
  padding: 5px 5px;
 
 
}
        .movie-cardA {
    width: 100%;
    height:100%;
    box-shadow: 20px 20px 50px rgba(0, 0, 0, 0.5);
    background: rgba(255,255,255,0.7);
    border-radius: 10px;
    padding: 20px;
    overflow: auto;
  }
  
  .movie-cardA img {
    width: 100%;
    border-radius: 10px;
  }
  
  .movie-cardA h2 {
    font-size: 24px;
    margin-top: 10px;
    margin-bottom: 5px;
  }
  
  .movie-cardA p {
    font-size: 14px;
    margin-bottom: 5px;
  }
  
  .movie-cardA .button-group {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 5px;
    margin-top: 10px;
  }
  
  .movie-cardA .button-group button {
    background-color: transparent;
    border: none;
    color: #555;
    font-size: 16px;
    cursor: pointer;
    position: relative;
    padding-left: 20px;
    padding-right: 20px;
  }
  
  .movie-cardA .button-group button:hover {
    color: black;

  }
  /* .button-trailer{
    position: relative;
    display: grid;
    grid-template-rows: 2fr;
  
  } */
  
  /* .movie-cardA .button-group button .button-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #555;
    position: absolute;
    left: 6px;
    top: 50%;
    transform: translateY(-50%);
    color: white;
  } */
  .btn {

    display: inline-block;
    font-size: 16px;
    font-weight: bold;
    color: white;
    background-color: rgb(33, 0, 48);
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    text-decoration: none;
    transition: background-color 0.3s ease;
  }
  
  .btn:hover {
    background-color: #0069d9;
  }
    </style>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="aside_con">
 <div class="movie-cardA">
    <img src="images/<?php echo htmlspecialchars($movies['images']);?>" alt="Movie Poster">
    <h2><?php echo htmlspecialchars($movies['title']);?></h2>
    <p>Release Year: <?php echo htmlspecialchars($movies['released_date']);?></p>
    <p>Genre:<?php echo htmlspecialchars($movies['genre']);?></p>
    <p>Director: <?php echo htmlspecialchars($movies['director']);?> </p>
    <p>Cast: <?php echo htmlspecialchars($movies['main_actors']);?></p>
    <p>Description: <?php echo htmlspecialchars($movies['descriptions']);?></p>
    <div class="button-group">
   <!--       <button class="button-trailer"><span class="button-circle"><i class="fa-solid fa-star"></i></span><h4>Trailer</h4></button> -->
       <a href="#" class="btn btn-primary"><i class="fa-solid fa-clapperboard"></i> Watch Trailer</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-play"></i> Watch Now</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-add"></i> Add to Library</a>
      <!-- <button class="button-watch"><span class="button-circle"></span>Watch</button>
      <button class="button-library"><span class="button-circle"></span>Add to Library</button> -->
    </div>
 </div>
</div>
</body>
</html>
 <!-- <div class="movie-cardA" id="d2">
    <img src="images/img2.jpg" alt="Movie Poster">
    <h2>t</h2>
    <p>Release Year: 2023</p>
    <p>Genre: Action, Adventure, Sci-Fi</p>
    <p>Director: John Doe</p>
    <p>Cast: Jane Doe, Bob Smith, Sarah Lee</p>
    <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    <div class="button-group">
     <button class="button-trailer"><span class="button-circle"><i class="fa-solid fa-star"></i></span><h4>Trailer</h4></button> -->
      <!--  <a href="#" class="btn btn-primary"><i class="fa-solid fa-clapperboard"></i> Watch Trailer</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-play"></i> Watch Now</a>
      <a href="#" class="btn btn-primary"><i class="fa-solid fa-add"></i> Add to Library</a> -->
      <!-- <button class="button-watch"><span class="button-circle"></span>Watch</button>
      <button class="button-library"><span class="button-circle"></span>Add to Library</button> -->
   <!--  </div>
   </div> - -->