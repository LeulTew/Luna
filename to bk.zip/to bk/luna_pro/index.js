let btn=document.querySelector('#btn');
    let  sidebar=document.querySelector('.sidebar');


    btn.onclick=function(){
        sidebar.classList.toggle('active');
    };

    // Get all clickable elements
const clickables = document.querySelectorAll('.movie-card');
const clickables1 = document.querySelectorAll('.series_list .movie-card');


// Add click event listener to each clickable elements
clickables.forEach(clickable => {
  clickable.addEventListener('click', () => {
    // Get the ID of the clicked element
    const id = clickable.id;
    // Send an AJAX request to fetch data
    const xhr = new XMLHttpRequest();
    xhr.open('get', `aside_con.php?id=${id}`);
    xhr.onload = function() {
      if (xhr.status === 200) {
        // Display the fetched data in the result div
        document.getElementById('d2').innerHTML = xhr.responseText;
      } else {
        console.log('Request failed. Status:', xhr.status);
      }
    };
    xhr.send();
  });
});
clickables1.forEach(clickable1 => {
  clickable1.addEventListener('click', () => {
    // Get the ID of the clicked element
    const id = clickable1.id;
    // Send an AJAX request to fetch data
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `aside_con_ser.php?id=${id}`);
    xhr.onload = function() {
      if (xhr.status === 200) {
        // Display the fetched data in the result div
        document.getElementById('d2').innerHTML = xhr.responseText;
      } else {
        console.log('Request failed. Status:', xhr.status);
      }
    };
    xhr.send();
  });
});
