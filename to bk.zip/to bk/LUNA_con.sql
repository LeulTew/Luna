-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 29, 2023 at 07:31 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `LUNA_con`
--

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `descriptions` text DEFAULT NULL,
  `released_date` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `director` varchar(255) DEFAULT NULL,
  `main_actors` text DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `no_views` int(11) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `title`, `genre`, `descriptions`, `released_date`, `duration`, `director`, `main_actors`, `rating`, `no_views`, `images`) VALUES
(1, 'John wick', 'Action', 'With the untimely death of his beloved wife still bitter in his mouth, John Wick, the expert former assassin, receives one final gift from her--a precious keepsake to help John find a new meaning in life now that she is gone. But when the arrogant Russian mob prince, Iosef Tarasov, and his men pay Wick a rather unwelcome visit to rob him of his prized 1969 Mustang and his wife\'s present, the legendary hitman will be forced to unearth his meticulously concealed identity. Blind with revenge, John will immediately unleash a carefully orchestrated maelstrom of destruction against the sophisticated kingpin, Viggo Tarasov, and his family, who are fully aware of his lethal capacity. Now, only blood can quench the boogeyman\'s thirst for retribution.', '2014-05-15', 101, 'David Leitch', 'Keanu Reeves , Michael Nyqvist , Alfie Allen', 7.4, 1230, 'image6.jpg'),
(3, 'Bullet Train', 'Comedy', 'Unlucky assassin Ladybug (Brad Pitt) is determined to do his job peacefully after one too many gigs has gone off the rails. Fate has other plans, however: Ladybug\'s latest mission puts him on a collision course with lethal adversaries from around the globe--all with connected, yet conflicting, objectives--on the world\'s fastest train. The end of the line is just the beginning in this non-stop thrill-ride through modern-day Japan.', '2022-08-18', 127, 'David Leitch', 'Brad PittJoey , King Aaron,  Taylor-Johnson', 7.3, 200000, 'img7.jpg'),
(4, 'John Wick:4', 'action', 'John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.', '2023-05-02', 170, 'Chad Stahelski', 'Keanu Reeves ,Laurence Fishburne ,George Georgiou\r\n', 8.1, 125000, 'john-wick-4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `series`
--

CREATE TABLE `series` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `descriptions` text DEFAULT NULL,
  `released_date` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `director` varchar(255) DEFAULT NULL,
  `main_actors` varchar(255) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `no_views` int(11) DEFAULT NULL,
  `no_season` int(11) DEFAULT NULL,
  `no_episode` int(11) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `series`
--

INSERT INTO `series` (`id`, `title`, `genre`, `descriptions`, `released_date`, `duration`, `director`, `main_actors`, `rating`, `no_views`, `no_season`, `no_episode`, `images`) VALUES
(1, 'MONEY HEIST', 'Adventure', 'A criminal mastermind who goes by \"The Professor\" has a plan to pull off the biggest heist in recorded history -- to print billions of euros in the Royal Mint of Spain. To help him carry out the ambitious plan, he recruits eight people with certain abilities and who have nothing to lose. The group of thieves take hostages to aid in their negotiations with the authorities, who strategize to come up with a way to capture The Professor. As more time elapses, the robbers prepare for a showdown with the police.', '2017-05-02', 45, 'Migue Amoedo', 'Úrsula Corberó, Álvaro Morte, Itziar Ituño', 8.50, 1255000, 4, 24, 'image4.jpg'),
(2, 'Game of thrones', 'Adventure', 'In the mythical continent of Westeros, several powerful families fight for control of the Seven Kingdoms. As conflict erupts in the kingdoms of men, an ancient enemy rises once again to threaten them all. Meanwhile, the last heirs of a recently usurped dynasty plot to take back their homeland from across the Narrow Sea.', '2012-05-03', 51, 'David Benioff', 'Emilia Clarke ,Peter Dinklage ,Kit Harington', 9.20, 120000, 8, 152, 'img5.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `series`
--
ALTER TABLE `series`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
